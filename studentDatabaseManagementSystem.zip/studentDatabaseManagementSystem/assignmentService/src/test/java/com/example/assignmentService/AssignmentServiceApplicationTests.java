package com.example.assignmentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
