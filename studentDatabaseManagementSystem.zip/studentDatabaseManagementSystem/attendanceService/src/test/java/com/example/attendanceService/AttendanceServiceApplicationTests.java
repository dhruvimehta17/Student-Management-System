package com.example.attendanceService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
